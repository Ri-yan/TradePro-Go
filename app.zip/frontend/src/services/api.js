import axios from 'axios';

const API_BASE = process.env.REACT_APP_API_URL || '/api';

const api = axios.create({ baseURL: API_BASE });

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

export const authAPI = {
  login: (email, password) => api.post('/auth/login', { email, password }),
};

export const marketAPI = {
  search: (query) => api.get('/market/search', { params: { q: query } }),
  getHistory: (symbol, days) => api.get('/market/history', { params: { symbol, days } }),
  getSymbols: () => api.get('/market/symbols'),
  refresh: () => api.post('/market/refresh'),
};

export default api;
