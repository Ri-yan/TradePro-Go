import React, { useState } from 'react';

export default function PriceTable({ data, days }) {
  const [sortCol, setSortCol] = useState('date');
  const [sortDir, setSortDir] = useState('desc');

  if (!data || data.length === 0) return null;

  const displayData = days === 1 ? data.slice(-1) : [...data].slice(-30);

  const sorted = [...displayData].sort((a, b) => {
    let aVal = a[sortCol];
    let bVal = b[sortCol];
    if (sortCol === 'date') {
      aVal = new Date(aVal);
      bVal = new Date(bVal);
    }
    if (aVal < bVal) return sortDir === 'asc' ? -1 : 1;
    if (aVal > bVal) return sortDir === 'asc' ? 1 : -1;
    return 0;
  });

  const handleSort = (col) => {
    if (sortCol === col) {
      setSortDir((d) => (d === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortCol(col);
      setSortDir('desc');
    }
  };

  const SortIcon = ({ col }) => {
    if (sortCol !== col) return <span style={{ opacity: 0.3 }}>⇅</span>;
    return <span>{sortDir === 'asc' ? '↑' : '↓'}</span>;
  };

  const columns = [
    { key: 'date', label: 'Date' },
    { key: 'open', label: 'Open' },
    { key: 'high', label: 'High' },
    { key: 'low', label: 'Low' },
    { key: 'close', label: 'Close' },
    { key: 'volume', label: 'Volume' },
    { key: 'change', label: 'Change' },
    { key: 'change_pct', label: 'Change %' },
  ];

  return (
    <div style={styles.container}>
      <h3 style={styles.title}>Price History — {days === 1 ? 'Today' : 'Last 30 Days'}</h3>
      <div style={styles.tableWrap}>
        <table style={styles.table}>
          <thead>
            <tr>
              {columns.map((col) => (
                <th key={col.key} style={styles.th} onClick={() => handleSort(col.key)}>
                  {col.label} <SortIcon col={col.key} />
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {sorted.map((row, i) => {
              const positive = row.change_pct >= 0;
              return (
                <tr key={i} style={i % 2 === 0 ? styles.rowEven : styles.rowOdd}>
                  <td style={styles.td}>{new Date(row.date).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' })}</td>
                  <td style={styles.td}>${row.open?.toFixed(2)}</td>
                  <td style={{ ...styles.td, color: '#22c55e' }}>${row.high?.toFixed(2)}</td>
                  <td style={{ ...styles.td, color: '#ef4444' }}>${row.low?.toFixed(2)}</td>
                  <td style={{ ...styles.td, fontWeight: '600' }}>${row.close?.toFixed(2)}</td>
                  <td style={styles.td}>{(row.volume / 1000000).toFixed(2)}M</td>
                  <td style={{ ...styles.td, color: positive ? '#22c55e' : '#ef4444' }}>
                    {positive ? '+' : ''}{row.change?.toFixed(2)}
                  </td>
                  <td style={{ ...styles.td, color: positive ? '#22c55e' : '#ef4444' }}>
                    {positive ? '+' : ''}{row.change_pct?.toFixed(2)}%
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

const styles = {
  container: {
    background: '#1e2433',
    borderRadius: '12px',
    border: '1px solid #2d3548',
    overflow: 'hidden',
  },
  title: {
    padding: '16px 20px',
    margin: 0,
    fontSize: '15px',
    fontWeight: '600',
    color: '#e5e7eb',
    borderBottom: '1px solid #2d3548',
  },
  tableWrap: { overflowX: 'auto' },
  table: { width: '100%', borderCollapse: 'collapse', fontSize: '13px' },
  th: {
    padding: '12px 16px',
    textAlign: 'left',
    color: '#6b7280',
    fontWeight: '600',
    cursor: 'pointer',
    userSelect: 'none',
    background: '#161b27',
    borderBottom: '1px solid #2d3548',
    whiteSpace: 'nowrap',
  },
  td: {
    padding: '10px 16px',
    color: '#d1d5db',
    whiteSpace: 'nowrap',
  },
  rowEven: { background: '#1e2433' },
  rowOdd: { background: '#1a2030' },
};
