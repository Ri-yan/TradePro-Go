import React, { useState, useCallback, useRef } from 'react';
import { marketAPI } from '../services/api';

export default function SearchBar({ onSelect }) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);
  const timeoutRef = useRef(null);

  const search = useCallback(async (q) => {
    if (!q.trim()) {
      setResults([]);
      setOpen(false);
      return;
    }
    setLoading(true);
    try {
      const res = await marketAPI.search(q);
      setResults(res.data.results || []);
      setOpen(true);
    } catch {
      setResults([]);
    } finally {
      setLoading(false);
    }
  }, []);

  const handleChange = (e) => {
    const val = e.target.value;
    setQuery(val);
    clearTimeout(timeoutRef.current);
    timeoutRef.current = setTimeout(() => search(val), 300);
  };

  const handleSelect = (item) => {
    onSelect(item);
    setQuery('');
    setOpen(false);
    setResults([]);
  };

  return (
    <div style={styles.wrapper}>
      <div style={styles.inputWrap}>
        <span style={styles.icon}>🔍</span>
        <input
          type="text"
          value={query}
          onChange={handleChange}
          placeholder="Search stocks & funds..."
          style={styles.input}
          onBlur={() => setTimeout(() => setOpen(false), 200)}
          onFocus={() => results.length > 0 && setOpen(true)}
        />
        {loading && <span style={styles.spinner}>⟳</span>}
      </div>

      {open && results.length > 0 && (
        <div style={styles.dropdown}>
          {results.map((r) => (
            <div key={r.symbol} style={styles.item} onMouseDown={() => handleSelect(r)}>
              <div style={styles.itemLeft}>
                <span style={styles.symbol}>{r.symbol}</span>
                <span style={styles.name}>{r.name}</span>
              </div>
              <div style={styles.itemRight}>
                <span style={styles.price}>${r.price?.toFixed(2)}</span>
                <span style={{ ...styles.change, color: r.change_pct >= 0 ? '#22c55e' : '#ef4444' }}>
                  {r.change_pct >= 0 ? '+' : ''}{r.change_pct?.toFixed(2)}%
                </span>
              </div>
            </div>
          ))}
        </div>
      )}

      {open && results.length === 0 && !loading && query && (
        <div style={styles.dropdown}>
          <div style={styles.noResult}>No results found for "{query}"</div>
        </div>
      )}
    </div>
  );
}

const styles = {
  wrapper: { position: 'relative', width: '280px' },
  inputWrap: {
    display: 'flex', alignItems: 'center', gap: '8px',
    background: '#0f1117', border: '1px solid #2d3548', borderRadius: '8px',
    padding: '8px 12px',
  },
  icon: { fontSize: '14px', opacity: 0.6 },
  input: {
    background: 'transparent', border: 'none', outline: 'none',
    color: '#fff', fontSize: '14px', flex: 1,
  },
  spinner: { color: '#6b7280', fontSize: '16px', animation: 'spin 1s linear infinite' },
  dropdown: {
    position: 'absolute', top: '100%', left: 0, right: 0, zIndex: 100,
    background: '#1e2433', border: '1px solid #2d3548', borderRadius: '8px',
    marginTop: '4px', maxHeight: '300px', overflowY: 'auto',
    boxShadow: '0 10px 25px rgba(0,0,0,0.5)',
  },
  item: {
    display: 'flex', alignItems: 'center', justifyContent: 'space-between',
    padding: '10px 14px', cursor: 'pointer', borderBottom: '1px solid #2d3548',
  },
  itemLeft: { display: 'flex', flexDirection: 'column', gap: '2px' },
  symbol: { color: '#fff', fontWeight: '600', fontSize: '14px' },
  name: { color: '#6b7280', fontSize: '12px' },
  itemRight: { display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: '2px' },
  price: { color: '#e5e7eb', fontSize: '14px', fontWeight: '500' },
  change: { fontSize: '12px', fontWeight: '500' },
  noResult: { padding: '16px', color: '#6b7280', textAlign: 'center', fontSize: '14px' },
};
