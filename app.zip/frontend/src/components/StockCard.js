import React, { useState, useEffect } from 'react';
import { marketAPI } from '../services/api';

export default function StockCard({ symbol, isSelected, onClick }) {
  const [latest, setLatest] = useState(null);

  useEffect(() => {
    marketAPI.getHistory(symbol.symbol, 2)
      .then((res) => {
        const data = res.data?.data;
        if (data && data.length > 0) {
          setLatest(data[data.length - 1]);
        }
      })
      .catch(() => {});
  }, [symbol.symbol]);

  const price = latest?.close ?? 0;
  const change = latest?.change ?? 0;
  const changePct = latest?.change_pct ?? 0;
  const positive = changePct >= 0;

  return (
    <div
      onClick={onClick}
      style={{
        ...styles.card,
        ...(isSelected ? styles.cardSelected : {}),
      }}
    >
      <div style={styles.topRow}>
        <span style={styles.symbol}>{symbol.symbol}</span>
        <span style={{ ...styles.badge, background: symbol.asset_type === 'mutual_fund' ? '#1e3a5f' : '#1a2e1a' }}>
          {symbol.asset_type === 'mutual_fund' ? 'Fund' : 'Stock'}
        </span>
      </div>
      <p style={styles.name}>{symbol.name}</p>
      <div style={styles.priceRow}>
        <span style={styles.price}>${price.toFixed(2)}</span>
        <span style={{ ...styles.change, color: positive ? '#22c55e' : '#ef4444' }}>
          {positive ? '▲' : '▼'} {Math.abs(changePct).toFixed(2)}%
        </span>
      </div>
      <div style={{ ...styles.changeDollar, color: positive ? '#22c55e' : '#ef4444' }}>
        {positive ? '+' : ''}{change.toFixed(2)} today
      </div>
    </div>
  );
}

const styles = {
  card: {
    background: '#1e2433',
    border: '1px solid #2d3548',
    borderRadius: '12px',
    padding: '16px',
    cursor: 'pointer',
    transition: 'all 0.2s',
  },
  cardSelected: {
    border: '1px solid #3b82f6',
    background: '#1a2340',
    boxShadow: '0 0 0 1px #3b82f6',
  },
  topRow: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' },
  symbol: { color: '#fff', fontWeight: '700', fontSize: '16px' },
  badge: {
    color: '#9ca3af', fontSize: '11px', borderRadius: '4px',
    padding: '2px 6px', fontWeight: '500',
  },
  name: { color: '#6b7280', fontSize: '12px', marginBottom: '12px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' },
  priceRow: { display: 'flex', justifyContent: 'space-between', alignItems: 'center' },
  price: { color: '#e5e7eb', fontSize: '18px', fontWeight: '600' },
  change: { fontSize: '14px', fontWeight: '600' },
  changeDollar: { fontSize: '12px', marginTop: '4px' },
};
