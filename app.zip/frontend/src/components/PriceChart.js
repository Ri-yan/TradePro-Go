import React from 'react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ReferenceLine,
} from 'recharts';

function CustomTooltip({ active, payload, label }) {
  if (!active || !payload || !payload.length) return null;
  const d = payload[0].payload;
  return (
    <div style={tooltipStyles.box}>
      <p style={tooltipStyles.date}>{label}</p>
      <p style={tooltipStyles.row}><span style={tooltipStyles.label}>Close</span><span>${d.close?.toFixed(2)}</span></p>
      <p style={tooltipStyles.row}><span style={tooltipStyles.label}>Open</span><span>${d.open?.toFixed(2)}</span></p>
      <p style={tooltipStyles.row}><span style={tooltipStyles.label}>High</span><span style={{ color: '#22c55e' }}>${d.high?.toFixed(2)}</span></p>
      <p style={tooltipStyles.row}><span style={tooltipStyles.label}>Low</span><span style={{ color: '#ef4444' }}>${d.low?.toFixed(2)}</span></p>
      <p style={{ ...tooltipStyles.row, color: d.change_pct >= 0 ? '#22c55e' : '#ef4444' }}>
        <span style={tooltipStyles.label}>Change</span>
        <span>{d.change_pct >= 0 ? '+' : ''}{d.change_pct?.toFixed(2)}%</span>
      </p>
    </div>
  );
}

export default function PriceChart({ data, days }) {
  if (!data || data.length === 0) return null;

  const chartData = data.map((d) => ({
    ...d,
    date: days === 1
      ? new Date(d.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      : new Date(d.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
  }));

  const prices = chartData.map((d) => d.close);
  const minPrice = Math.min(...prices) * 0.999;
  const maxPrice = Math.max(...prices) * 1.001;
  const firstClose = chartData[0]?.close ?? 0;
  const lastClose = chartData[chartData.length - 1]?.close ?? 0;
  const isPositive = lastClose >= firstClose;

  const gradientId = isPositive ? 'positiveGrad' : 'negativeGrad';
  const lineColor = isPositive ? '#22c55e' : '#ef4444';

  return (
    <div style={styles.container}>
      <div style={styles.summary}>
        <span style={styles.price}>${lastClose.toFixed(2)}</span>
        <span style={{ ...styles.change, color: isPositive ? '#22c55e' : '#ef4444' }}>
          {isPositive ? '▲' : '▼'} {Math.abs(lastClose - firstClose).toFixed(2)} ({Math.abs(((lastClose - firstClose) / firstClose) * 100).toFixed(2)}%)
        </span>
        <span style={styles.period}>{days === 1 ? 'Today' : 'Last 30 Days'}</span>
      </div>

      <ResponsiveContainer width="100%" height={300}>
        <AreaChart data={chartData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
          <defs>
            <linearGradient id="positiveGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#22c55e" stopOpacity={0.3} />
              <stop offset="95%" stopColor="#22c55e" stopOpacity={0} />
            </linearGradient>
            <linearGradient id="negativeGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#ef4444" stopOpacity={0.3} />
              <stop offset="95%" stopColor="#ef4444" stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="#2d3548" />
          <XAxis
            dataKey="date"
            tick={{ fill: '#6b7280', fontSize: 11 }}
            tickLine={false}
            axisLine={false}
            interval="preserveStartEnd"
          />
          <YAxis
            domain={[minPrice, maxPrice]}
            tick={{ fill: '#6b7280', fontSize: 11 }}
            tickLine={false}
            axisLine={false}
            tickFormatter={(v) => `$${v.toFixed(0)}`}
            width={60}
          />
          <Tooltip content={<CustomTooltip />} />
          <ReferenceLine y={firstClose} stroke="#4b5563" strokeDasharray="4 4" />
          <Area
            type="monotone"
            dataKey="close"
            stroke={lineColor}
            strokeWidth={2}
            fill={`url(#${gradientId})`}
            dot={false}
            activeDot={{ r: 4, fill: lineColor }}
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}

const styles = {
  container: {
    background: '#1e2433',
    borderRadius: '12px',
    padding: '20px',
    border: '1px solid #2d3548',
    marginBottom: '16px',
  },
  summary: { display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '16px', flexWrap: 'wrap' },
  price: { color: '#fff', fontSize: '28px', fontWeight: '700' },
  change: { fontSize: '16px', fontWeight: '600' },
  period: { color: '#6b7280', fontSize: '13px', marginLeft: 'auto' },
};

const tooltipStyles = {
  box: {
    background: '#1e2433', border: '1px solid #2d3548', borderRadius: '8px',
    padding: '10px 14px', fontSize: '13px', color: '#e5e7eb',
  },
  date: { color: '#9ca3af', marginBottom: '6px', fontWeight: '600' },
  row: { display: 'flex', justifyContent: 'space-between', gap: '16px', marginBottom: '2px' },
  label: { color: '#6b7280' },
};
