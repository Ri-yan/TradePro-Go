import React, { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../context/AuthContext';
import { marketAPI } from '../services/api';
import SearchBar from '../components/SearchBar';
import StockCard from '../components/StockCard';
import PriceChart from '../components/PriceChart';
import PriceTable from '../components/PriceTable';

const DEFAULT_SYMBOLS = ['AAPL', 'GOOGL', 'MSFT', 'NVDA', 'TSLA'];

export default function Dashboard() {
  const { user, logout } = useAuth();
  const [watchlist, setWatchlist] = useState([]);
  const [selected, setSelected] = useState(null);
  const [history, setHistory] = useState(null);
  const [historyDays, setHistoryDays] = useState(30);
  const [historyLoading, setHistoryLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState('');

  const loadWatchlist = useCallback(async () => {
    try {
      const res = await marketAPI.getSymbols();
      const symbols = res.data.symbols || [];
      const defaultItems = symbols
        .filter((s) => DEFAULT_SYMBOLS.includes(s.symbol))
        .slice(0, 6);
      if (defaultItems.length === 0 && symbols.length > 0) {
        setWatchlist(symbols.slice(0, 6));
      } else {
        setWatchlist(defaultItems);
      }
    } catch (e) {
      setError('Failed to load market data');
    }
  }, []);

  const loadHistory = useCallback(async (symbol, days) => {
    setHistoryLoading(true);
    setError('');
    try {
      const res = await marketAPI.getHistory(symbol, days);
      setHistory(res.data);
    } catch (e) {
      setError(`Failed to load history for ${symbol}`);
      setHistory(null);
    } finally {
      setHistoryLoading(false);
    }
  }, []);

  useEffect(() => {
    loadWatchlist();
  }, [loadWatchlist]);

  useEffect(() => {
    if (selected) {
      loadHistory(selected, historyDays);
    }
  }, [selected, historyDays, loadHistory]);

  const handleSearch = async (result) => {
    setSelected(result.symbol);
    if (!watchlist.find((w) => w.symbol === result.symbol)) {
      setWatchlist((prev) => [result, ...prev].slice(0, 8));
    }
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    try {
      await marketAPI.refresh();
      setTimeout(() => {
        loadWatchlist();
        if (selected) loadHistory(selected, historyDays);
        setRefreshing(false);
      }, 3000);
    } catch {
      setRefreshing(false);
    }
  };

  const now = new Date();

  return (
    <div style={styles.container}>
      {/* Header */}
      <header style={styles.header}>
        <div style={styles.headerLeft}>
          <span style={styles.headerLogo}>📈</span>
          <div>
            <h1 style={styles.headerTitle}>TradePro</h1>
            <p style={styles.headerDate}>
              {now.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
            </p>
          </div>
        </div>
        <div style={styles.headerRight}>
          <SearchBar onSelect={handleSearch} />
          <button onClick={handleRefresh} style={styles.refreshBtn} disabled={refreshing}>
            {refreshing ? '⟳ Refreshing...' : '⟳ Refresh'}
          </button>
          <div style={styles.userInfo}>
            <span style={styles.userAvatar}>{user?.name?.[0] || 'U'}</span>
            <span style={styles.userName}>{user?.name}</span>
          </div>
          <button onClick={logout} style={styles.logoutBtn}>Sign Out</button>
        </div>
      </header>

      <main style={styles.main}>
        {error && <div style={styles.errorBanner}>{error}</div>}

        {/* Watchlist */}
        <section style={styles.section}>
          <h2 style={styles.sectionTitle}>Market Overview</h2>
          <div style={styles.watchlist}>
            {watchlist.map((item) => (
              <StockCard
                key={item.symbol}
                symbol={item}
                isSelected={selected === item.symbol}
                onClick={() => setSelected(item.symbol)}
              />
            ))}
          </div>
        </section>

        {/* Chart + Table Area */}
        {selected && (
          <section style={styles.section}>
            <div style={styles.chartHeader}>
              <div>
                <h2 style={styles.sectionTitle}>{history?.name || selected}</h2>
                <span style={styles.assetType}>{history?.asset_type === 'mutual_fund' ? 'Mutual Fund' : 'Stock'}</span>
              </div>
              <div style={styles.periodButtons}>
                {[{ label: '1 Day', days: 1 }, { label: '30 Days', days: 30 }].map(({ label, days }) => (
                  <button
                    key={days}
                    onClick={() => setHistoryDays(days)}
                    style={{
                      ...styles.periodBtn,
                      ...(historyDays === days ? styles.periodBtnActive : {}),
                    }}
                  >
                    {label}
                  </button>
                ))}
              </div>
            </div>

            {historyLoading ? (
              <div style={styles.loading}>Loading chart data...</div>
            ) : history?.data ? (
              <>
                <PriceChart data={history.data} days={historyDays} />
                <PriceTable data={history.data} days={historyDays} />
              </>
            ) : (
              <div style={styles.noData}>No data available for this period</div>
            )}
          </section>
        )}

        {!selected && (
          <div style={styles.selectPrompt}>
            <div style={styles.selectIcon}>🔍</div>
            <p>Search for a stock or mutual fund, or click a card above to view price history</p>
          </div>
        )}
      </main>
    </div>
  );
}

const styles = {
  container: { minHeight: '100vh', background: '#0f1117' },
  header: {
    background: '#1e2433',
    borderBottom: '1px solid #2d3548',
    padding: '16px 32px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    flexWrap: 'wrap',
    gap: '16px',
  },
  headerLeft: { display: 'flex', alignItems: 'center', gap: '12px' },
  headerLogo: { fontSize: '32px' },
  headerTitle: { fontSize: '20px', fontWeight: '700', color: '#fff', margin: 0 },
  headerDate: { fontSize: '12px', color: '#6b7280', margin: 0 },
  headerRight: { display: 'flex', alignItems: 'center', gap: '12px', flexWrap: 'wrap' },
  refreshBtn: {
    background: '#2d3548',
    color: '#9ca3af',
    border: '1px solid #3d4660',
    borderRadius: '8px',
    padding: '8px 14px',
    cursor: 'pointer',
    fontSize: '13px',
  },
  userInfo: { display: 'flex', alignItems: 'center', gap: '8px' },
  userAvatar: {
    width: '32px', height: '32px', borderRadius: '50%',
    background: 'linear-gradient(135deg, #3b82f6, #1d4ed8)',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    fontSize: '14px', fontWeight: '700',
  },
  userName: { color: '#e5e7eb', fontSize: '14px' },
  logoutBtn: {
    background: 'transparent',
    color: '#6b7280',
    border: '1px solid #2d3548',
    borderRadius: '8px',
    padding: '8px 14px',
    cursor: 'pointer',
    fontSize: '13px',
  },
  main: { padding: '24px 32px', maxWidth: '1400px', margin: '0 auto' },
  errorBanner: {
    background: '#2d1b1b', border: '1px solid #dc2626', color: '#f87171',
    borderRadius: '8px', padding: '12px 16px', marginBottom: '16px', fontSize: '14px',
  },
  section: { marginBottom: '32px' },
  sectionTitle: { fontSize: '18px', fontWeight: '600', color: '#e5e7eb', marginBottom: '16px' },
  watchlist: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))',
    gap: '16px',
  },
  chartHeader: {
    display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between',
    marginBottom: '16px', flexWrap: 'wrap', gap: '12px',
  },
  assetType: {
    background: '#2d3548', color: '#9ca3af', borderRadius: '4px',
    padding: '2px 8px', fontSize: '11px', fontWeight: '500',
  },
  periodButtons: { display: 'flex', gap: '8px' },
  periodBtn: {
    background: '#1e2433', color: '#9ca3af', border: '1px solid #2d3548',
    borderRadius: '8px', padding: '8px 16px', cursor: 'pointer', fontSize: '13px',
  },
  periodBtnActive: {
    background: 'linear-gradient(135deg, #3b82f6, #1d4ed8)',
    color: '#fff', border: '1px solid transparent',
  },
  loading: { textAlign: 'center', padding: '60px', color: '#6b7280' },
  noData: { textAlign: 'center', padding: '60px', color: '#6b7280' },
  selectPrompt: {
    textAlign: 'center', padding: '60px', color: '#4b5563',
    background: '#1e2433', borderRadius: '12px', border: '1px dashed #2d3548',
  },
  selectIcon: { fontSize: '48px', marginBottom: '16px' },
};
