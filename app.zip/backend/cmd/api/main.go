package main

import (
	"database/sql"
	"log"
	"os"
	"time"

	"trading-dashboard/internal/auth"
	"trading-dashboard/internal/handlers"
	"trading-dashboard/internal/repository"
	"trading-dashboard/internal/services"

	"github.com/gin-contrib/cors"
	"github.com/gin-gonic/gin"
	_ "github.com/lib/pq"
	"github.com/robfig/cron/v3"
)

func main() {
	dbURL := os.Getenv("DATABASE_URL")
	if dbURL == "" {
		dbURL = "postgres://trader:trader123@localhost:5432/tradingdb?sslmode=disable"
	}

	var db *sql.DB
	var err error
	for i := 0; i < 10; i++ {
		db, err = sql.Open("postgres", dbURL)
		if err == nil {
			err = db.Ping()
		}
		if err == nil {
			break
		}
		log.Printf("Waiting for database... attempt %d/10", i+1)
		time.Sleep(3 * time.Second)
	}
	if err != nil {
		log.Fatalf("Failed to connect to database: %v", err)
	}
	defer db.Close()

	if err := repository.RunMigrations(db); err != nil {
		log.Fatalf("Failed to run migrations: %v", err)
	}

	jwtSecret := os.Getenv("JWT_SECRET")
	if jwtSecret == "" {
		jwtSecret = "super-secret-jwt-key-change-in-production"
	}

	userRepo := repository.NewUserRepository(db)
	marketRepo := repository.NewMarketRepository(db)

	authService := auth.NewService(jwtSecret)
	marketService := services.NewMarketService(marketRepo)

	authHandler := handlers.NewAuthHandler(userRepo, authService)
	marketHandler := handlers.NewMarketHandler(marketService)

	// Seed default user
	if err := userRepo.SeedDefaultUser(); err != nil {
		log.Printf("Warning: could not seed default user: %v", err)
	}

	// Schedule market data fetch every hour
	c := cron.New()
	c.AddFunc("@hourly", func() {
		log.Println("Running scheduled market data fetch...")
		if err := marketService.FetchAndStore(); err != nil {
			log.Printf("Scheduled fetch error: %v", err)
		}
	})
	c.Start()

	// Initial fetch on startup
	go func() {
		time.Sleep(2 * time.Second)
		log.Println("Running initial market data fetch...")
		if err := marketService.FetchAndStore(); err != nil {
			log.Printf("Initial fetch error: %v", err)
		}
	}()

	router := gin.Default()
	router.Use(cors.New(cors.Config{
		AllowOrigins:     []string{"http://localhost:3000", "http://frontend:3000"},
		AllowMethods:     []string{"GET", "POST", "PUT", "DELETE", "OPTIONS"},
		AllowHeaders:     []string{"Origin", "Content-Type", "Authorization"},
		ExposeHeaders:    []string{"Content-Length"},
		AllowCredentials: true,
		MaxAge:           12 * time.Hour,
	}))

	// Public routes
	router.POST("/api/auth/login", authHandler.Login)
	router.GET("/api/health", func(c *gin.Context) {
		c.JSON(200, gin.H{"status": "ok"})
	})

	// Protected routes
	protected := router.Group("/api")
	protected.Use(authService.Middleware())
	{
		protected.GET("/market/search", marketHandler.Search)
		protected.GET("/market/history", marketHandler.GetHistory)
		protected.GET("/market/symbols", marketHandler.GetSymbols)
		protected.POST("/market/refresh", marketHandler.RefreshData)
	}

	port := os.Getenv("PORT")
	if port == "" {
		port = "8080"
	}

	log.Printf("Server starting on port %s", port)
	if err := router.Run(":" + port); err != nil {
		log.Fatalf("Server failed: %v", err)
	}
}
