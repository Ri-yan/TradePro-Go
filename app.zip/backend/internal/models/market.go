package models

import "time"

type MarketPrice struct {
	ID        int       `json:"id"`
	Symbol    string    `json:"symbol"`
	Name      string    `json:"name"`
	AssetType string    `json:"asset_type"` // "stock" or "mutual_fund"
	Price     float64   `json:"price"`
	Open      float64   `json:"open"`
	High      float64   `json:"high"`
	Low       float64   `json:"low"`
	Volume    int64     `json:"volume"`
	Change    float64   `json:"change"`
	ChangePct float64   `json:"change_pct"`
	Date      time.Time `json:"date"`
	CreatedAt time.Time `json:"created_at"`
}

type Symbol struct {
	Symbol    string `json:"symbol"`
	Name      string `json:"name"`
	AssetType string `json:"asset_type"`
}

type SearchResult struct {
	Symbol    string  `json:"symbol"`
	Name      string  `json:"name"`
	AssetType string  `json:"asset_type"`
	Price     float64 `json:"price"`
	Change    float64 `json:"change"`
	ChangePct float64 `json:"change_pct"`
}

type HistoryResponse struct {
	Symbol    string        `json:"symbol"`
	Name      string        `json:"name"`
	AssetType string        `json:"asset_type"`
	Data      []PricePoint  `json:"data"`
}

type PricePoint struct {
	Date      string  `json:"date"`
	Open      float64 `json:"open"`
	High      float64 `json:"high"`
	Low       float64 `json:"low"`
	Close     float64 `json:"close"`
	Volume    int64   `json:"volume"`
	Change    float64 `json:"change"`
	ChangePct float64 `json:"change_pct"`
}
