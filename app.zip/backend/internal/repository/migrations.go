package repository

import (
	"database/sql"
	"log"
)

func RunMigrations(db *sql.DB) error {
	log.Println("Running database migrations...")

	migrations := []string{
		`CREATE TABLE IF NOT EXISTS users (
			id SERIAL PRIMARY KEY,
			email VARCHAR(255) UNIQUE NOT NULL,
			password_hash VARCHAR(255) NOT NULL,
			name VARCHAR(255) NOT NULL,
			created_at TIMESTAMP DEFAULT NOW()
		)`,
		`CREATE TABLE IF NOT EXISTS market_prices (
			id SERIAL PRIMARY KEY,
			symbol VARCHAR(20) NOT NULL,
			name VARCHAR(255) NOT NULL,
			asset_type VARCHAR(50) NOT NULL DEFAULT 'stock',
			price DECIMAL(18,4) NOT NULL,
			open DECIMAL(18,4) DEFAULT 0,
			high DECIMAL(18,4) DEFAULT 0,
			low DECIMAL(18,4) DEFAULT 0,
			volume BIGINT DEFAULT 0,
			change DECIMAL(18,4) DEFAULT 0,
			change_pct DECIMAL(10,4) DEFAULT 0,
			date DATE NOT NULL,
			created_at TIMESTAMP DEFAULT NOW(),
			UNIQUE(symbol, date)
		)`,
		`CREATE INDEX IF NOT EXISTS idx_market_symbol ON market_prices(symbol)`,
		`CREATE INDEX IF NOT EXISTS idx_market_date ON market_prices(date)`,
	}

	for _, m := range migrations {
		if _, err := db.Exec(m); err != nil {
			return err
		}
	}

	log.Println("Migrations completed successfully")
	return nil
}
