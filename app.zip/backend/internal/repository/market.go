package repository

import (
	"database/sql"
	"fmt"
	"time"

	"trading-dashboard/internal/models"
)

type MarketRepository struct {
	db *sql.DB
}

func NewMarketRepository(db *sql.DB) *MarketRepository {
	return &MarketRepository{db: db}
}

func (r *MarketRepository) UpsertPrice(p *models.MarketPrice) error {
	_, err := r.db.Exec(`
		INSERT INTO market_prices (symbol, name, asset_type, price, open, high, low, volume, change, change_pct, date)
		VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
		ON CONFLICT (symbol, date) DO UPDATE SET
			price = EXCLUDED.price,
			open = EXCLUDED.open,
			high = EXCLUDED.high,
			low = EXCLUDED.low,
			volume = EXCLUDED.volume,
			change = EXCLUDED.change,
			change_pct = EXCLUDED.change_pct,
			name = EXCLUDED.name
	`, p.Symbol, p.Name, p.AssetType, p.Price, p.Open, p.High, p.Low, p.Volume, p.Change, p.ChangePct, p.Date.Format("2006-01-02"))
	return err
}

func (r *MarketRepository) SearchSymbols(query string) ([]models.SearchResult, error) {
	rows, err := r.db.Query(`
		SELECT DISTINCT ON (symbol) symbol, name, asset_type, price, change, change_pct
		FROM market_prices
		WHERE symbol ILIKE $1 OR name ILIKE $1
		ORDER BY symbol, date DESC
		LIMIT 20
	`, "%"+query+"%")
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var results []models.SearchResult
	for rows.Next() {
		var r models.SearchResult
		if err := rows.Scan(&r.Symbol, &r.Name, &r.AssetType, &r.Price, &r.Change, &r.ChangePct); err != nil {
			continue
		}
		results = append(results, r)
	}
	return results, nil
}

func (r *MarketRepository) GetHistory(symbol string, days int) (*models.HistoryResponse, error) {
	since := time.Now().AddDate(0, 0, -days).Format("2006-01-02")

	rows, err := r.db.Query(`
		SELECT symbol, name, asset_type, price, open, high, low, volume, change, change_pct, date
		FROM market_prices
		WHERE symbol = $1 AND date >= $2
		ORDER BY date ASC
	`, symbol, since)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	resp := &models.HistoryResponse{Symbol: symbol}
	for rows.Next() {
		var p models.MarketPrice
		var dateStr string
		if err := rows.Scan(&p.Symbol, &p.Name, &p.AssetType, &p.Price, &p.Open, &p.High, &p.Low, &p.Volume, &p.Change, &p.ChangePct, &dateStr); err != nil {
			continue
		}
		resp.Name = p.Name
		resp.AssetType = p.AssetType
		resp.Data = append(resp.Data, models.PricePoint{
			Date:      dateStr,
			Open:      p.Open,
			High:      p.High,
			Low:       p.Low,
			Close:     p.Price,
			Volume:    p.Volume,
			Change:    p.Change,
			ChangePct: p.ChangePct,
		})
	}

	if resp.Name == "" {
		return nil, fmt.Errorf("symbol not found: %s", symbol)
	}
	return resp, nil
}

func (r *MarketRepository) GetAllSymbols() ([]models.Symbol, error) {
	rows, err := r.db.Query(`
		SELECT DISTINCT symbol, name, asset_type FROM market_prices ORDER BY symbol
	`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var symbols []models.Symbol
	for rows.Next() {
		var s models.Symbol
		if err := rows.Scan(&s.Symbol, &s.Name, &s.AssetType); err != nil {
			continue
		}
		symbols = append(symbols, s)
	}
	return symbols, nil
}
