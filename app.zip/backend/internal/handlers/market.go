package handlers

import (
	"net/http"
	"strconv"

	"trading-dashboard/internal/services"

	"github.com/gin-gonic/gin"
)

type MarketHandler struct {
	service *services.MarketService
}

func NewMarketHandler(service *services.MarketService) *MarketHandler {
	return &MarketHandler{service: service}
}

func (h *MarketHandler) Search(c *gin.Context) {
	query := c.Query("q")
	if query == "" {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Query parameter 'q' is required"})
		return
	}

	results, err := h.service.Search(query)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Search failed"})
		return
	}

	if results == nil {
		c.JSON(http.StatusOK, gin.H{"results": []string{}})
		return
	}

	c.JSON(http.StatusOK, gin.H{"results": results})
}

func (h *MarketHandler) GetHistory(c *gin.Context) {
	symbol := c.Query("symbol")
	if symbol == "" {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Query parameter 'symbol' is required"})
		return
	}

	daysStr := c.DefaultQuery("days", "30")
	days, err := strconv.Atoi(daysStr)
	if err != nil || days < 1 || days > 365 {
		days = 30
	}

	history, err := h.service.GetHistory(symbol, days)
	if err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, history)
}

func (h *MarketHandler) GetSymbols(c *gin.Context) {
	symbols, err := h.service.GetAllSymbols()
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to get symbols"})
		return
	}

	if symbols == nil {
		c.JSON(http.StatusOK, gin.H{"symbols": []string{}})
		return
	}

	c.JSON(http.StatusOK, gin.H{"symbols": symbols})
}

func (h *MarketHandler) RefreshData(c *gin.Context) {
	go func() {
		if err := h.service.FetchAndStore(); err != nil {
			// Log error but don't fail the response
			_ = err
		}
	}()
	c.JSON(http.StatusOK, gin.H{"message": "Data refresh initiated"})
}
