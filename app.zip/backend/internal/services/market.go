package services

import (
	"encoding/json"
	"fmt"
	"log"
	"math"
	"math/rand"
	"net/http"
	"time"

	"trading-dashboard/internal/models"
	"trading-dashboard/internal/repository"
)

// Symbols to track - mix of stocks and mutual funds
var trackedSymbols = []struct {
	Symbol    string
	Name      string
	AssetType string
	BasePrice float64
}{
	{"AAPL", "Apple Inc.", "stock", 185.0},
	{"GOOGL", "Alphabet Inc.", "stock", 140.0},
	{"MSFT", "Microsoft Corporation", "stock", 375.0},
	{"AMZN", "Amazon.com Inc.", "stock", 178.0},
	{"TSLA", "Tesla Inc.", "stock", 250.0},
	{"NVDA", "NVIDIA Corporation", "stock", 480.0},
	{"META", "Meta Platforms Inc.", "stock", 500.0},
	{"JPM", "JPMorgan Chase & Co.", "stock", 195.0},
	{"V", "Visa Inc.", "stock", 272.0},
	{"JNJ", "Johnson & Johnson", "stock", 155.0},
	{"VFINX", "Vanguard 500 Index Fund", "mutual_fund", 420.0},
	{"FXAIX", "Fidelity 500 Index Fund", "mutual_fund", 185.0},
	{"VTSAX", "Vanguard Total Stock Market", "mutual_fund", 115.0},
	{"AGTHX", "American Funds Growth Fund", "mutual_fund", 72.0},
	{"PRGFX", "T. Rowe Price Growth Stock", "mutual_fund", 95.0},
}

type alphaVantageResponse struct {
	TimeSeries map[string]struct {
		Open   string `json:"1. open"`
		High   string `json:"2. high"`
		Low    string `json:"3. low"`
		Close  string `json:"4. close"`
		Volume string `json:"5. volume"`
	} `json:"Time Series (Daily)"`
}

type MarketService struct {
	repo       *repository.MarketRepository
	httpClient *http.Client
	apiKey     string
}

func NewMarketService(repo *repository.MarketRepository, apiKey string) *MarketService {
	if apiKey == "" {
		apiKey = "demo"
	}
	return &MarketService{
		repo:       repo,
		httpClient: &http.Client{Timeout: 10 * time.Second},
		apiKey:     apiKey,
	}
}

func (s *MarketService) FetchAndStore() error {
	log.Println("Fetching market data...")
	// Try to fetch from Alpha Vantage; fall back to simulated data
	for _, sym := range trackedSymbols {
		prices := s.fetchSymbolData(sym.Symbol, sym.Name, sym.AssetType, sym.BasePrice)
		for _, p := range prices {
			if err := s.repo.UpsertPrice(&p); err != nil {
				log.Printf("Error storing %s: %v", sym.Symbol, err)
			}
		}
	}
	log.Println("Market data fetch complete")
	return nil
}

func (s *MarketService) fetchSymbolData(symbol, name, assetType string, basePrice float64) []models.MarketPrice {
	// Try Alpha Vantage first
	if data := s.fetchFromAlphaVantage(symbol, name, assetType); len(data) > 0 {
		return data
	}
	// Fall back to deterministic simulated data
	return s.generateSimulatedData(symbol, name, assetType, basePrice)
}

func (s *MarketService) fetchFromAlphaVantage(symbol, name, assetType string) []models.MarketPrice {
	url := fmt.Sprintf(
		"https://www.alphavantage.co/query?function=TIME_SERIES_DAILY&symbol=%s&outputsize=compact&apikey=%s",
		symbol, s.apiKey,
	)

	resp, err := s.httpClient.Get(url)
	if err != nil {
		return nil
	}
	defer resp.Body.Close()

	var avResp alphaVantageResponse
	if err := json.NewDecoder(resp.Body).Decode(&avResp); err != nil || avResp.TimeSeries == nil {
		return nil
	}

	var prices []models.MarketPrice
	for dateStr, v := range avResp.TimeSeries {
		date, err := time.Parse("2006-01-02", dateStr)
		if err != nil {
			continue
		}

		var open, high, low, closePrice float64
		var volume int64
		fmt.Sscanf(v.Open, "%f", &open)
		fmt.Sscanf(v.High, "%f", &high)
		fmt.Sscanf(v.Low, "%f", &low)
		fmt.Sscanf(v.Close, "%f", &closePrice)
		fmt.Sscanf(v.Volume, "%d", &volume)

		change := closePrice - open
		changePct := 0.0
		if open > 0 {
			changePct = (change / open) * 100
		}

		prices = append(prices, models.MarketPrice{
			Symbol:    symbol,
			Name:      name,
			AssetType: assetType,
			Price:     closePrice,
			Open:      open,
			High:      high,
			Low:       low,
			Volume:    volume,
			Change:    change,
			ChangePct: changePct,
			Date:      date,
		})
	}
	return prices
}

func (s *MarketService) generateSimulatedData(symbol, name, assetType string, basePrice float64) []models.MarketPrice {
	// Use a seeded random based on symbol for deterministic but varied data
	seed := int64(0)
	for _, c := range symbol {
		seed += int64(c)
	}
	rng := rand.New(rand.NewSource(seed))

	var prices []models.MarketPrice
	price := basePrice
	today := time.Now()

	for i := 60; i >= 0; i-- {
		date := today.AddDate(0, 0, -i)
		// Skip weekends
		if date.Weekday() == time.Saturday || date.Weekday() == time.Sunday {
			continue
		}

		dailyVolatility := 0.02
		openOffset := (rng.Float64() - 0.5) * price * dailyVolatility
		open := math.Round((price+openOffset)*100) / 100
		closeChange := (rng.Float64() - 0.48) * price * dailyVolatility
		closePrice := math.Round((open+closeChange)*100) / 100
		high := math.Round(math.Max(open, closePrice)*(1+rng.Float64()*0.01)*100) / 100
		low := math.Round(math.Min(open, closePrice)*(1-rng.Float64()*0.01)*100) / 100
		volume := int64(1000000 + rng.Intn(5000000))

		change := math.Round((closePrice-open)*100) / 100
		changePct := 0.0
		if open > 0 {
			changePct = math.Round((change/open)*10000) / 100
		}

		prices = append(prices, models.MarketPrice{
			Symbol:    symbol,
			Name:      name,
			AssetType: assetType,
			Price:     closePrice,
			Open:      open,
			High:      high,
			Low:       low,
			Volume:    volume,
			Change:    change,
			ChangePct: changePct,
			Date:      date,
		})
		price = closePrice
	}
	return prices
}

func (s *MarketService) Search(query string) ([]models.SearchResult, error) {
	return s.repo.SearchSymbols(query)
}

func (s *MarketService) GetHistory(symbol string, days int) (*models.HistoryResponse, error) {
	return s.repo.GetHistory(symbol, days)
}

func (s *MarketService) GetAllSymbols() ([]models.Symbol, error) {
	return s.repo.GetAllSymbols()
}
