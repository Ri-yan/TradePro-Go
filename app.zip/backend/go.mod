module trading-dashboard

go 1.21

require (
	github.com/gin-gonic/gin v1.9.1
	github.com/golang-jwt/jwt/v5 v5.2.0
	github.com/lib/pq v1.10.9
	github.com/joho/godotenv v1.5.1
	golang.org/x/crypto v0.17.0
	github.com/gin-contrib/cors v1.5.0
	github.com/robfig/cron/v3 v3.0.1
)
